document.getElementById("get-weather").addEventListener("click", () => {
  const location = document.getElementById("location").value.trim();

  if (!location) {
    alert("Please enter a location");
    return;
  }

  // Replace 'Lahore' with the user input location in the API request URL
  fetch(
    `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=e5730c917dead66f8da0ce5ebee55a52&units=metric`
  )
    .then((response) => {
      if (!response.ok) {
        throw new Error("Weather data not found");
      }
      return response.json();
    })
    .then((data) => {
      const temp = data.main.temp;
      const humidity = data.main.humidity;
      const windSpeed = data.wind.speed;
      const precipitation = 43; // Assuming a fixed value for now

      document.getElementById("weather-info").innerHTML = `
                <div class="weather-card" style="margin-top: 20px;">
                    <div class="weather-details" style="margin-bottom: 20px; font-size: 20px;">Temperature: ${temp}°C</div>
                    <div class="weather-details">
                        <p>Precipitation: ${precipitation}%</p>
                        <p>Humidity: ${humidity}%</p>
                        <p>Wind: ${windSpeed} km/h</p>
                    </div>
                </div>
            `;
    })
    .catch((error) => {
      console.error("Error fetching weather data:", error);
      document.getElementById("weather-info").innerHTML =
        "<p>Error fetching weather data. Please try again.</p>";
    });
});
